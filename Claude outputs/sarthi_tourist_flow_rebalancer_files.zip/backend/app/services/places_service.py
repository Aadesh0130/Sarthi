import hashlib

from sqlalchemy.orm import Session

from app.core.cache import cache_get, cache_get_stale, cache_set
from app.core.config import get_settings
from app.integrations.base import ProviderError
from app.integrations.overpass import OverpassProvider
from app.schemas.place import Place, PlaceDetails, Settlement

settings = get_settings()
_provider = OverpassProvider()


def _key(prefix: str, *parts: str) -> str:
    raw = "|".join(parts)
    return f"{prefix}:{hashlib.sha1(raw.encode()).hexdigest()}"


def _distance_meters(lat1, lon1, lat2, lon2) -> float:
    from math import atan2, cos, radians, sin, sqrt
    r = 6371000.0
    dlat, dlon = radians(lat2 - lat1), radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    return r * 2 * atan2(sqrt(a), sqrt(1 - a))


async def nearby_places(
    db: Session, latitude: float, longitude: float, radius_meters: int, categories: list[str],
    meta: dict | None = None,
) -> list[Place]:
    """`meta`, when passed as an empty dict, is filled in with
    `stale_seconds` when the result had to fall back to an out-of-date cache
    entry because every live mirror failed on this call (see
    cache_get_stale) -- callers that want to label that honestly (the
    /api/places/nearby route) can check it; callers that don't care
    (recommendations, the AI planner, crowd pressure, ...) can simply omit
    it and get the same resilience for free."""
    key = _key("nearby", f"{latitude:.4f}", f"{longitude:.4f}", str(radius_meters), ",".join(sorted(categories)))
    cached = cache_get(db, key)
    if cached is not None:
        places = [Place(**item) for item in cached]
    else:
        try:
            places = await _provider.nearby(latitude, longitude, radius_meters, categories)
        except ProviderError:
            stale = cache_get_stale(db, key, settings.cache_ttl_places, settings.cache_stale_grace_places)
            if stale is None:
                raise  # nothing live, nothing cached either -- an honest failure, not a guess
            payload, age_seconds = stale
            places = [Place(**item) for item in payload]
            if meta is not None:
                meta["stale_seconds"] = age_seconds
        else:
            cache_set(db, key, [p.model_dump() for p in places], settings.cache_ttl_places)

    for p in places:
        p.distance_meters = round(_distance_meters(latitude, longitude, p.latitude, p.longitude), 1)

    # Overpass's "around:" filter guarantees every matched element genuinely has some part
    # of its geometry within the radius -- but for a way/relation (a long ghat, a river, an
    # administrative boundary...) the "out center" coordinate it hands back is the bounding-
    # box centroid of the WHOLE feature, which can land far outside the radius even though
    # only a sliver of it actually matched nearby. That shows up as a real OSM place plotted
    # hundreds of km from the searched destination. Rather than surface that centroid
    # artifact as a "nearby" result, drop anything whose computed distance is well past the
    # radius actually asked for.
    max_distance = radius_meters * 1.5
    places = [p for p in places if p.distance_meters is not None and p.distance_meters <= max_distance]

    places.sort(key=lambda p: p.distance_meters or 0)
    return places


async def nearby_settlements(
    db: Session, latitude: float, longitude: float, radius_meters: int, meta: dict | None = None,
) -> list[Settlement]:
    """Real nearby towns/villages (not tourist POIs) -- candidate discovery
    for the Tourist Flow Rebalancer. Same cache-then-live-then-stale-fallback
    pattern as nearby_places, under its own cache-key prefix so it never
    collides with (or duplicates a request already made by) the POI cache."""
    key = _key("settlements", f"{latitude:.4f}", f"{longitude:.4f}", str(radius_meters))
    cached = cache_get(db, key)
    if cached is not None:
        settlements = [Settlement(**item) for item in cached]
    else:
        try:
            settlements = await _provider.nearby_settlements(latitude, longitude, radius_meters)
        except ProviderError:
            stale = cache_get_stale(db, key, settings.cache_ttl_places, settings.cache_stale_grace_places)
            if stale is None:
                raise
            payload, age_seconds = stale
            settlements = [Settlement(**item) for item in payload]
            if meta is not None:
                meta["stale_seconds"] = age_seconds
        else:
            cache_set(db, key, [s.model_dump() for s in settlements], settings.cache_ttl_places)
    return settlements


async def get_place_details(db: Session, place_id: str) -> PlaceDetails | None:
    key = _key("details", place_id)
    cached = cache_get(db, key)
    if cached is not None:
        return PlaceDetails(**cached) if cached else None

    details = await _provider.get_details(place_id)
    cache_set(db, key, details.model_dump() if details else None, settings.cache_ttl_places)
    return details
